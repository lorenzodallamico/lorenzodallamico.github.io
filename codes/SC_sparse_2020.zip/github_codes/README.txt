This is the version of the code that was used to produce the results presented in our paper "A unified framework for spectral clustering in sparse graphs" submitted to the Journal of Machine Learning Reasearch.

In this folder, one can find

1) Dataset	: in this folder there are the 15 real networks datasets as downloaded at the publicly available sources indicated in the article.
2) Package	: this folder is used by the notebooks and inside are stored the two files with all the functions 
	a) generic_functions.py	 : here one can find the implementation of some functions of general use for community detection in DC-SBM generated graphs
	b) clustering.py	 : this file contains the implementation of Algorithm 2 described in the article
	c) other_clustering_functions.py 	:	this file contains the implementation of the clustering algorithms discussed in the 
		
3) The file base_env.yml: it contains all the information about the Python environment in which the simulations were conducted.
4) The folder Notebooks: it contains the notebooks with the implementation of the simulations needed to obtain the result in the article. The name of the notebook indicates which result the notebook reproduces.
5) The notebook Demo : it gives a small demo of how to use the main functions and comments the main bits of Algorithm 2
