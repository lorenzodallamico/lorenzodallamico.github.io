import numpy as np
import matplotlib.pyplot as plt
import scipy.sparse.linalg
import random
random.seed;
import time
import itertools
import networkx as nx
import sys
from sklearn.cluster import KMeans
from scipy.sparse import coo_matrix, bmat
from networkx.algorithms.community.quality import modularity

import sys
sys.path += ['/localdata/dallamil-admin/Scrivania/Work/A_Progetti/Community detection/Articolo/github_codes/Package/']  ### Specify the directory where the Package is
from generic_functions import *
from clustering import *



class ReturnValue:
    def __init__(self, estimated_labels, n_clusters, ov, mod):
        self.estimated_labels = estimated_labels
        self.n_clusters = n_clusters
        self.overlap = ov
        self.modularity = mod

############################################################################################################################

def Bethe_Hessian_clustering(A, *args, **kwargs):
    
    '''Function to perform community detection on a graph with n nodes and k communities using the Bethe-Hessian matrix according to the algorithm of Saade et al. 2014
    Use : 
        cluster = Bethe_Hessian_clustering(A, **kwargs)
    Input :
        A (sparse matrix n x n) : adjacency matrix
        **kwargs:
            n_max (scalar) : maximal number of possible classes to look for during the estimation. If not specified set equal to 80
            real_classes (array of size n) : vector containing the true labels of the network. If not specified set to None
            n_clusters (scalar) : number of clusters k. If not specified it will be estimated
            
    Output :
        cluster.estimated_labels (array of size n) : vector containing the estimated labels
        cluster.n_clusters (scalar) : estimated values of k used in the k-means step
        cluster.overlap (scalar) : overlap with respect to the known partition
        cluster.modularity (scalar) : modularity of the estimated partition
    
    '''
    
    n_max = kwargs.get('n_max', 80)
    real_classes = kwargs.get('real_classes', [None])
    n_clusters = kwargs.get('n_clusters', None)
    
    d = np.array(np.sum(A,axis = 0))[0] # degree vector
    n = len(d) # size of the network
    D = scipy.sparse.diags(d, offsets = 0)
    I = scipy.sparse.diags(np.ones(n), offsets = 0)
    r = np.sqrt(find_rho_B(A)) # r = sqrt{rho(B)}
 
    H = (r**2-1)*I + D - r*A # Bethe-Hessian matrix
    
    if n_clusters == None: # it the number of clusters is not known, we estimate it  
        
        n_clusters = 1 
        flag = 0
        while flag == 0:
            if n_clusters < n_max: # the algo will not find more than n_max clusters
                v, X = scipy.sparse.linalg.eigsh(H, k = n_clusters + 1 , which='SA') # smallest eigenvalues of H_r
                if max(v) < -np.finfo(float).eps: #  if informative
                    n_clusters += 1
                else:
                    flag = 1
            else:
                flag = 1

    v, X = scipy.sparse.linalg.eigsh(H, k = n_clusters, which='SA') # smallest eigenvalues of H_r
    idx = v.argsort() # sort the eigenvalues
    X[:,0] = np.ones(n) # discard the first eigenvector


    kmeans = KMeans(n_clusters = n_clusters) # perform kmeans on the informative eigenvectors
    kmeans.fit(X)
    estimated_labels = kmeans.predict(X)

    if real_classes[0] == None:
        ov = 'Not available'
    else:
        ov = overlap(real_classes, estimated_labels) # compute the overlap
        
    
    mod =  find_modularity(A, estimated_labels) # compute the modularity

    return ReturnValue(estimated_labels, n_clusters, ov, mod)



############################################################################################################################


def Non_backtracking_clustering(A, *args, **kwargs):
    
    '''Function to perform community detection on a graph with n nodes and k communities using the non-backtracking matrix according to the algorithm of Krzakala et al. 2013
    Use : 
        cluster = Non_backtracking_clustering(A, **kwargs)
    Input :
        A (sparse matrix n x n) : adjacency matrix
        **kwargs:
            n_max (scalar) : maximal number of possible classes to look for during the estimation. If not specified set equal to 80
            real_classes (array of size n) : vector containing the true labels of the network. If not specified set to None
            n_clusters (scalar) : number of clusters k. If not specified it will estimate it
            
    Output :
        cluster.estimated_labels (array of size n) : vector containing the estimated labels
        cluster.n_clusters (scalar) : estimated values of k used in the k-means step
        cluster.overlap (scalar) : overlap with respect to the known partition
        cluster.modularity (scalar) : modularity of the estimated partition
    
    '''
    
    n_max = kwargs.get('n_max', 80)
    real_classes = kwargs.get('real_classes', [None])
    n_clusters = kwargs.get('n_clusters', None)
    
    d = np.array(np.sum(A,axis = 0))[0] # degree vector
    n = len(d) # size of the network
    D = scipy.sparse.diags(d, offsets = 0)
    I = scipy.sparse.diags(np.ones(n), offsets = 0)
    
    if n_clusters == None: # it the number of clusters is not known, we estimate it  
        
        r = np.sqrt(find_rho_B(A)) # r = sqrt{rho(B)}
        n_clusters = 1 
        H = (r**2-1)*I + D - r*A # Bethe-Hessian matrix
        flag = 0
        while flag == 0:
            if n_clusters < n_max: # the algo will not find more than n_max clusters
                v = scipy.sparse.linalg.eigsh(H, k = n_clusters + 1 , which='SA', return_eigenvectors = False) # smallest eigenvalues of H_r
                if max(v) < -np.finfo(float).eps: #  if informative
                    n_clusters += 1
                else:
                    flag = 1
            else:
                flag = 1

    nu_p_v = dominant_B(A, n_clusters) # vector containing the positions of the largest eigenvalues of B in decreasing order
    X = np.ones((n, n_clusters))
    
    for i in range(1, n_clusters):
        
        r = nu_p_v[i] # select the value of  r
        H = (r**2-1)*I + D - r*A
        v, Y = scipy.sparse.linalg.eigsh(H, k = i+1 , which='SA') # smallest eigenvalues of H_r
        idx = v.argsort()  
        Y = Y[:,idx]
        X[:,i] = Y[:,-1] # keep the i+1 smallest eigenvector
        
    kmeans = KMeans(n_clusters = n_clusters) # perform kmeans on the informative eigenvector
    kmeans.fit(X)
    estimated_labels = kmeans.predict(X)

    if real_classes[0] == None:
        ov = 'Not available'
    else:
        ov = overlap(real_classes, estimated_labels) # compute the overlap
        
    
    mod =  find_modularity(A, estimated_labels) # compute the modularity

    return ReturnValue(estimated_labels, n_clusters, ov, mod)


############################################################################################################################

def Laplacian_clustering(A, n_clusters, *args, **kwargs):
    
    '''Function to perform community detection on a graph with n nodes and k communities using the Laplacian matrix according to the algorithm of Shi Malik (2000)
    Use : 
        cluster = Laplacian_clustering(A, n_clusters, *args, **kwargs)
    Input :
        A (sparse matrix n x n) : adjacency matrix
        n_clusters (scalar) : number of communitiess
        **kwargs:
            real_classes (array of size n) : vector containing the true labels of the network. If not specified set to None
    
    Outup :
        cluster.estimated_labels (array of size n) : vector containing the estimated labels
        cluster.overlap (scalar) : overlap with respect to the known partition
        cluster.modularity (scalar) : modularity of the estimated partition
    
    '''
    
    real_classes = kwargs.get('real_classes', [None])
    
    d = np.array(np.sum(A,axis = 0))[0] # degree vector
    v = np.where(d != 0)[0] # get rid of the disconnected nodes, so that D is invertible
    if real_classes[0] != None:
        real_classes = real_classes[v]
    A = A[v][:,v]
    d = np.array(np.sum(A,axis = 0))[0] # degree vector
    n = len(d) # size of the network
    D_05 = scipy.sparse.diags(d**(-1/2), offsets = 0)
    
    L = D_05.dot(A).dot(D_05) # symmetric  Laplacian
    v, X = scipy.sparse.linalg.eigsh(L, k = n_clusters , which='LA') # largest eigenvalues and eigenvectors of L
    X = D_05.dot(X) # recovering the eigenvalues of D^{-1}A
        
    kmeans = KMeans(n_clusters = n_clusters) # perform kmeans on the informative eigenvector
    kmeans.fit(X)
    estimated_labels = kmeans.predict(X)

    if real_classes[0] == None:
        ov = 'Not available'
    else:
        ov = overlap(real_classes, estimated_labels) # compute the overlap

    mod =  find_modularity(A, estimated_labels) # compute the modularity

    return ReturnValue(estimated_labels, n_clusters, ov, mod)

############################################################################################################################

def Adjaceny_clustering(A, n_clusters, *args, **kwargs):
    
    '''Function to perform community detection on a graph with n nodes and k communities using the leading eigenvectors of the adjacency matrix
    Use : 
        cluster = Adjaceny_clustering(A, n_clusters, *args, **kwargs)
    Input :
        A (sparse matrix n x n) : adjacency matrix
        n_clusters (scalar) : number of communitiess
        **kwargs:
            real_classes (array of size n) : vector containing the true labels of the network. If not specified set to None
            
    Outup :
        cluster.estimated_labels (array of size n) : vector containing the estimated labels
        cluster.overlap (scalar) : overlap with respect to the known partition
        cluster.modularity (scalar) : modularity of the estimated partition
    
    '''
    
    real_classes = kwargs.get('real_classes', [None])
    
    v, X = scipy.sparse.linalg.eigsh(A.astype(float), k = n_clusters , which='LA') # largest eigenvalues and eigenvectors of A
        
    kmeans = KMeans(n_clusters = n_clusters) # perform kmeans on the informative eigenvector
    kmeans.fit(X)
    estimated_labels = kmeans.predict(X)

    if real_classes[0] == None:
        ov = 'Not available'
    else:
        ov = overlap(real_classes, estimated_labels) # compute the overlap
        
    mod =  find_modularity(A, estimated_labels) # compute the modularity

    return ReturnValue(estimated_labels, n_clusters, ov, mod)

############################################################################################################################

def Regularized_laplacian_clustering(A, n_clusters, *args, **kwargs):
    
    '''Function to perform community detection on a graph with n nodes and k communities using the regularized Laplacian matrix according to the algorithm of  Qin Rohe (2013)
    Use : 
        cluster = Regularized_laplacian_clustering(A, n_clusters, *args, **kwargs)
    Input :
        A (sparse matrix n x n) : adjacency matrix
        n_clusters (scalar) : number of communitiess
        **kwargs:
            real_classes (array of size n) : vector containing the true labels of the network. If not specified set to None
            
    Outup :
        cluster.estimated_labels (array of size n) : vector containing the estimated labels
        cluster.overlap (scalar) : overlap with respect to the known partition
        cluster.modularity (scalar) : modularity of the estimated partition
    
    '''
    
    real_classes = kwargs.get('real_classes', [None])
    
    d = np.array(np.sum(A, axis = 0))[0]
    tau = np.mean(d) # tau equal to the  average degree
    n = len(d)
    Dtau_05 = scipy.sparse.diags((d + tau*np.ones(n))**(-1/2), offsets = 0) 
    Ltau = Dtau_05.dot(A).dot(Dtau_05) # L_tau
    v, X = scipy.sparse.linalg.eigsh(Ltau, k = n_clusters , which='LA') # largest eigenvalues and eigenvectors of L_tau
    for i in range(n):
        X[i] = X[i]/np.sqrt(np.sum(X[i]**2)) # normalize the rows  of X
    
    kmeans = KMeans(n_clusters = n_clusters) # perform kmeans on the informative eigenvector
    kmeans.fit(X)
    estimated_labels = kmeans.predict(X)

    if real_classes[0] == None:
        ov = 'Not available'
    else:
        ov = overlap(real_classes, estimated_labels) # compute the overlap
        
    mod =  find_modularity(A, estimated_labels) # compute the modularity

    return ReturnValue(estimated_labels, n_clusters, ov, mod)

############################################################################################################################


def community_detection_zeta_given(A, zeta_v, *args, **kwargs):
    
    '''Function to perform community detection on a graph with n nodes and k communities according to Algorithm 1, assuming zeta is given
    Use : 
        cluster = community_detection_zeta_given(A, zeta_v, **kwargs)
    Input :
        A (sparse matrix n x n) : adjacency matrix
        zeta_v (array of size k) : vector zeta
        **kwargs:
            real_classes (array of size n) : vector containing the true labels of the network. If not specified set to None
            
    Outup :
        cluster.estimated_labels (array of size n) : vector containing the estimated labels
        cluster.overlap (scalar) : overlap with respect to the known partition
        cluster.modularity (scalar) : modularity of the estimated partition
    
    '''
    
    real_classes = kwargs.get('real_classes', [None])
    
    d = np.array(np.sum(A,axis = 0))[0] # degree vector
    n = len(d) # size of the network
    
    n_clusters = len(zeta_v) # number of clusters
    X = np.ones((n, n_clusters))
    
    for i in range(1, n_clusters):
        
        tau = zeta_v[i]**2-1
        D_tau_05 = scipy.sparse.diags((d + (tau)*np.ones(n))**(-1/2), offsets = 0) 
        L_tau = D_tau_05.dot(A).dot(D_tau_05) # symmetric reduced Laplacian at tau = zeta_p^2-1
        v, Y = scipy.sparse.linalg.eigsh(L_tau, k = i + 1 , which='LA') # largest eigenvalues of L_tau
        idx = v.argsort()[::-1]  
        Y = Y[:,idx]
        X[:,i] = D_tau_05.dot(Y[:,-1]) # store the p-th largest eigenvector of D_tau^{-1}A

    kmeans = KMeans(n_clusters = n_clusters) # perform kmeans on the informative eigenvector
    kmeans.fit(X)
    estimated_labels = kmeans.predict(X)

    if real_classes[0] == None:
        ov = 'Not available'
    else:
        ov = overlap(real_classes, estimated_labels) # compute the overlap
        

    mod =  find_modularity(A, estimated_labels) # compute the modularity


    return ReturnValue(estimated_labels, n_clusters, ov, mod)
