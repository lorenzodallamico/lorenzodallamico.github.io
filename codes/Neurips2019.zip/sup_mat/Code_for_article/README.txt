This is the version of the code that was used to produce the results presented in our paper "Revisiting the Bethe-Hessian: Improved CommunityDetection in Sparse Heterogeneous Graphs" submitted to NIPS 2019. 

In this folder, one can find

	1) Dataset: in this folder there are the real datasets used to obtain the results of table  1
	2) Package: this folder is used by the notebooks and inside are stored the three files with all the functions (clustering.py, clustering_with_best.py, clustering_more.py)
	3) The file base_env.yml: it contains all the information about the Python environment in which the simulations were conducted.
	4) The notebooks:
		a) Eigenvector - Figure 4b: implementation of the algorithm to obtain the eigenvectors for the proposed algorithm, compared to (Saade2014). Approximate execution time : 20s
		b) Labelled_real_networks - Table 1 : implementation of the algorithm on real labelled networks and comparison with the other methods presented in Table 1. Approximate execution time: few seconds.
		c) Overlap comparison - Figure 4: comparison of the overlap of different spectral techniques for different values of alpha (hardness of the problem). Approximate execution time : 3h
		d) Simulated vs theoretical results - Figure 1 : comparison of the simulation with the theoretical results regarding mean and variance of the eigenvector and the theoretical prediction of the overlap. Approximate execution time: 3h
		e) spectrum_of_B - Figure 2 : behavior of the spectrum of the non-backtracking matrix for different values of alpha (hardness of the problem). Approximate execution time : 4h
		f) Unlabelled_real_networks- Table 1: implementation of the algorithm on real unlabelled networks and comparison with the other methods presented in Table 1. Approximate execution time: few minutes.
		e) Tuning r - figure 3 : overlap oh the Bethe-Hessian matrix as a function of r. Codes used to obtain figure 3. Approximate execution time: 3h.

	5) browsing.py : in this file we test the algorithm on a grid for different hardness of the problem and different number of clusters, to obtain the figure 2 of the supplementary material. Approximate execution time: several hours

	6) B_spec_more_classes.py : in this file we find the spectrum of the non-backtracking matrix for more then two classes, as shown in figure 1 of the supplementary material. Approximate execution time: few hours.
